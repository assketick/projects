package com.company.windows;

import com.company.realize.ATM;
import com.company.realize.CreditCard;
import com.company.realize.DebitCard;

import java.awt.*;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.PlainDocument;

public class StartWindow extends JFrame {
    private final ATM atm;

    public ATM getAtm() {

        return atm;
    }

    public StartWindow(String title, ATM atm) {
        super(title);
        this.atm = atm;
        setBounds(500, 250, 550, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(false);

        JButton exit = new JButton("Завершить");
        JButton enter = new JButton("Подтвердить");
        enter.setPreferredSize(new Dimension(30,40));
        enter.setFocusable(false);
        enter.setFocusPainted(false);
        enter.setFont(new Font("TimesRoman", Font.BOLD, 20));
        exit.setFocusable(false);
        JTextField first4 = new JTextField(4);
        JTextField second4 = new JTextField(4);
        JTextField third4 = new JTextField(4);
        JTextField fourth4 = new JTextField(4);
        JLabel startText = new JLabel("Введите номер карты");
        startText.setFont(new Font("TimesRoman", Font.BOLD, 25));

        PlainDocument document1 = (PlainDocument) first4.getDocument();
        PlainDocument document2 = (PlainDocument) second4.getDocument();
        PlainDocument document3 = (PlainDocument) third4.getDocument();
        PlainDocument document4 = (PlainDocument) fourth4.getDocument();
        DocumentFilter filter = new DocumentFilter(){
            @Override
            public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String string = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;

                if (string.length() <= 4 && isDigit(string)) {
                    super.replace(fb, offset, length, text, attrs); //To change body of generated methods, choose Tools | Templates.
                }
            }
        };
        document1.setDocumentFilter(filter);
        document2.setDocumentFilter(filter);
        document3.setDocumentFilter(filter);
        document4.setDocumentFilter(filter);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.BOTH;
        c.insets = new Insets(40, 135,0,0);
        c.gridx = 0;
        c.gridy = 0;
        panel.add(startText, c);

        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
        GridBagConstraints c1 = new GridBagConstraints();
        c1.insets = new Insets(10, 0,0,20);
        c1.gridx = 0;
        c1.gridy = 0;
        panel1.add(first4, c1);
        c1.gridx = 1;
        c1.gridy = 0;
        panel1.add(second4, c1);
        c1.gridx = 2;
        c1.gridy = 0;
        panel1.add(third4, c1);
        c1.insets = new Insets(10, 0,0,0);
        c1.gridx = 3;
        c1.gridy = 0;
        panel1.add(fourth4, c1);

        c.weightx = 2;
        c.weighty = 2;
        c.insets = new Insets(10,100,0,0);
        c.gridx = 0;
        c.gridy = 1;
        panel.add(panel1, c);

        c.weightx = 1;
        c.weighty = 1;
        c.insets = new Insets(20,100,0,0);
        c.gridx = 0;
        c.gridy = 2;
        panel.add(enter, c);
        c.weightx = 0;
        c.weighty = 0;
        c.insets = new Insets(20,0,0,0);
        c.gridx = 1;
        c.gridy = 3;
        panel.add(exit, c);
        add(panel);

        exit.addActionListener(e -> System.exit(0));

        enter.addActionListener(e -> {
            if (Objects.equals(first4.getText(), "") || Objects.equals(second4.getText(), "") ||
                    Objects.equals(third4.getText(), "") || Objects.equals(fourth4.getText(), "")) {
                JOptionPane.showMessageDialog(getMe(), "Заполните поля!", "Предупреждение",JOptionPane.WARNING_MESSAGE);
            }
            else if (first4.getText().length() < 4 || second4.getText().length() < 4 || third4.getText().length() < 4
                || fourth4.getText().length() < 4) {
                JOptionPane.showMessageDialog(getMe(), "В каждом поле должно быть по 4 цифры!", "Предупреждение",
                        JOptionPane.WARNING_MESSAGE);
            }
            else{
                String number = first4.getText() + " " + second4.getText() + " " + third4.getText() + " " + fourth4.getText();
                DebitCard card = atm.getCardByNumber(number);
                if (card == null){
                    JOptionPane.showMessageDialog(getMe(), "Данной карты не существует", "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                }
                else{
                    if (card.identify() == 1){
                        CreditCard creditCard = (CreditCard) card;
                        if (creditCard.getCalendar() != null) {
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(new Date());
                            int n = (int) ((calendar.getTimeInMillis()
                                    - creditCard.getCalendar().getTimeInMillis()) /
                                    (60000 * 1440 * 30));
                            creditCard.update(n);
                        }
                    }
                    first4.setText("");
                    second4.setText("");
                    third4.setText("");
                    fourth4.setText("");
                    new PinWindow("Pin", getMe(), card);
                }
            }
        });


        setVisible(true);
    }

    private boolean isDigit(String str){
        try{
            Integer.parseInt(str);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    private StartWindow getMe(){
        return this;
    }
}
