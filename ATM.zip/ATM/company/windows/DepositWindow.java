package com.company.windows;

import com.company.realize.DebitCard;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.PlainDocument;
import java.awt.*;
import java.awt.event.*;

public class DepositWindow extends JFrame {
    public DepositWindow(String title, DebitCard card, MainWindow mainWindow){
        super(title);
        setBounds(480, 200, 600, 500);
        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                mainWindow.setVisible(true);
                dispose();
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        setLayout(new GridBagLayout());
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints mainC = new GridBagConstraints();
        mainC.gridx = 0;
        mainC.gridy = 0;


        JLabel l50 = new JLabel("50");
        JLabel l100 = new JLabel("100");
        JLabel l200 = new JLabel("200");
        JLabel l500 = new JLabel("500");
        JLabel l1000 = new JLabel("1000");
        JLabel l2000 = new JLabel("2000");
        JLabel l5000 = new JLabel("5000");

        l50.setFont(new Font("TimesRoman", Font.BOLD, 25));
        l100.setFont(new Font("TimesRoman", Font.BOLD, 25));
        l200.setFont(new Font("TimesRoman", Font.BOLD, 25));
        l500.setFont(new Font("TimesRoman", Font.BOLD, 25));
        l1000.setFont(new Font("TimesRoman", Font.BOLD, 25));
        l2000.setFont(new Font("TimesRoman", Font.BOLD, 25));
        l5000.setFont(new Font("TimesRoman", Font.BOLD, 25));

        JTextField t50 = new JTextField("0", 3);
        JTextField t100 = new JTextField("0", 3);
        JTextField t200 = new JTextField("0", 3);
        JTextField t500 = new JTextField("0", 3);
        JTextField t1000 = new JTextField("0", 3);
        JTextField t2000 = new JTextField("0", 3);
        JTextField t5000 = new JTextField("0", 3);

        PlainDocument document1 = (PlainDocument) t50.getDocument();
        PlainDocument document2 = (PlainDocument) t100.getDocument();
        PlainDocument document3 = (PlainDocument) t200.getDocument();
        PlainDocument document4 = (PlainDocument) t500.getDocument();
        PlainDocument document5 = (PlainDocument) t1000.getDocument();
        PlainDocument document6 = (PlainDocument) t2000.getDocument();
        PlainDocument document7 = (PlainDocument) t5000.getDocument();
        DocumentFilter filter = new DocumentFilter(){
            @Override
            public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String string = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;

                if (isDigit(string)) {
                    super.replace(fb, offset, length, text, attrs); //To change body of generated methods, choose Tools | Templates.
                }
            }
        };

        document1.setDocumentFilter(filter);
        document2.setDocumentFilter(filter);
        document3.setDocumentFilter(filter);
        document4.setDocumentFilter(filter);
        document5.setDocumentFilter(filter);
        document6.setDocumentFilter(filter);
        document7.setDocumentFilter(filter);

        JButton input = new JButton("Внести");
        input.setFocusable(false);
        input.setPreferredSize(new Dimension(200,50));
        input.setFocusable(false);
        input.setFocusPainted(false);
        input.setFont(new Font("TimesRoman", Font.BOLD, 15));
        input.setFocusable(false);

        JButton back = new JButton("Назад");
        back.setFocusable(false);
        back.setPreferredSize(new Dimension(200,50));
        back.setFocusable(false);
        back.setFocusPainted(false);
        back.setFont(new Font("TimesRoman", Font.BOLD, 15));
        back.setFocusable(false);

        back.addActionListener(e -> {
            mainWindow.setVisible(true);
            dispose();
        });
        input.addActionListener(e -> {
            int c50 = Integer.parseInt(t50.getText());
            int c100 = Integer.parseInt(t100.getText());
            int c200 = Integer.parseInt(t200.getText());
            int c500 = Integer.parseInt(t500.getText());
            int c1000 = Integer.parseInt(t1000.getText());
            int c2000 = Integer.parseInt(t2000.getText());
            int c5000 = Integer.parseInt(t5000.getText());
            mainWindow.getStartWindow().getAtm().calcDeposit(c50, c100, c200, c500, c1000, c2000, c5000);
            int sum = c50 * 50 + c100 * 100 + c200 * 200 + c500 * 500 + c1000 * 1000 + c2000 * 2000 + c5000 * 5000;
            card.deposit(sum);
            mainWindow.getStartWindow().getAtm().incNum();
            JOptionPane.showMessageDialog(getMe(), "Деньги успешно внесены!", "Успешно", JOptionPane.PLAIN_MESSAGE);
            JOptionPane.showMessageDialog(getMe(), mainWindow.getStartWindow().getAtm().getCheque(card, sum, 0));
            mainWindow.setVisible(true);
            dispose();
        });

        MouseListener mouse = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                JTextField tf = (JTextField) e.getComponent();
                tf.setText("");
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        };
        FocusListener focus = new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {

            }

            @Override
            public void focusLost(FocusEvent e) {
                JTextField tf = (JTextField) e.getComponent();
                if (!isDigit(tf.getText())){
                    tf.setText("0");
                }
            }
        };

        t50.addMouseListener(mouse);
        t100.addMouseListener(mouse);
        t200.addMouseListener(mouse);
        t500.addMouseListener(mouse);
        t1000.addMouseListener(mouse);
        t2000.addMouseListener(mouse);
        t5000.addMouseListener(mouse);

        t50.addFocusListener(focus);
        t100.addFocusListener(focus);
        t200.addFocusListener(focus);
        t500.addFocusListener(focus);
        t1000.addFocusListener(focus);
        t2000.addFocusListener(focus);
        t5000.addFocusListener(focus);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        panel.add(l50, c);
        c.insets = new Insets(0,20,0,0);
        c.gridx = 1;
        panel.add(l100, c);
        c.gridx = 2;
        panel.add(l200, c);
        c.gridx = 3;
        panel.add(l500, c);
        c.gridx = 4;
        panel.add(l1000, c);
        c.gridx = 5;
        panel.add(l2000, c);
        c.gridx = 6;
        panel.add(l5000, c);

        c.insets = new Insets(20,0,0,0);
        c.gridx = 0;
        c.gridy = 1;
        panel.add(t50, c);
        c.insets = new Insets(20, 20, 0, 0);
        c.gridx = 1;
        panel.add(t100, c);
        c.gridx = 2;
        panel.add(t200, c);
        c.gridx = 3;
        panel.add(t500, c);
        c.gridx = 4;
        panel.add(t1000, c);
        c.gridx = 5;
        panel.add(t2000, c);
        c.gridx = 6;
        panel.add(t5000, c);

        mainPanel.add(panel, mainC);
        mainC.insets = new Insets(20,0,0,0);
        mainC.gridy = 1;
        mainPanel.add(input, mainC);
        mainC.gridy = 2;
        mainPanel.add(back, mainC);

        add(mainPanel);
        setVisible(true);
    }
    private boolean isDigit(String str){
        try{
            Integer.parseInt(str);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }
    private DepositWindow getMe(){
        return this;
    }
}
