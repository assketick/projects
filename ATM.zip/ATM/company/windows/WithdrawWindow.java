package com.company.windows;

import com.company.exceptions.IncorrectSumException;
import com.company.exceptions.NotEnoughMoneyException;
import com.company.realize.DebitCard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Objects;

public class WithdrawWindow extends JFrame {
    private final DebitCard card;
    private final MainWindow mainWindow;
    public WithdrawWindow(String title, DebitCard card, MainWindow mainWindow){
        super(title);
        this.card = card;
        this.mainWindow = mainWindow;
        setBounds(500, 250, 550, 400);
        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                mainWindow.setVisible(true);
                dispose();
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        setLayout(new BorderLayout());
        setResizable(false);

        JLabel text = new JLabel("Выберите сумму");
        text.setFont(new Font("TimesRoman", Font.BOLD, 20));

        JButton b500 = new JButton("500");
        b500.setFocusable(false);
        b500.setPreferredSize(new Dimension(100,35));
        b500.setFocusable(false);
        b500.setFocusPainted(false);
        b500.setFont(new Font("TimesRoman", Font.BOLD, 15));
        b500.setFocusable(false);

        JButton b1000 = new JButton("1000");
        b1000.setFocusable(false);
        b1000.setPreferredSize(new Dimension(100,35));
        b1000.setFocusable(false);
        b1000.setFocusPainted(false);
        b1000.setFont(new Font("TimesRoman", Font.BOLD, 15));
        b1000.setFocusable(false);

        JButton b5000 = new JButton("5000");
        b5000.setFocusable(false);
        b5000.setPreferredSize(new Dimension(100,35));
        b5000.setFocusable(false);
        b5000.setFocusPainted(false);
        b5000.setFont(new Font("TimesRoman", Font.BOLD, 15));
        b5000.setFocusable(false);

        JButton another = new JButton("Другая сумма");
        another.setFocusable(false);
        another.setPreferredSize(new Dimension(200,35));
        another.setFocusable(false);
        another.setFocusPainted(false);
        another.setFont(new Font("TimesRoman", Font.BOLD, 15));
        another.setFocusable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(0,0,20,0);
        c.gridx = 1;
        c.gridy = 0;
        panel.add(text, c);
        c.insets = new Insets(20,0,20,20);
        c.gridx = 0;
        c.gridy = 1;
        panel.add(b500, c);
        c.gridx = 1;
        c.gridy = 1;
        panel.add(b1000, c);
        c.insets = new Insets(20,0,20,0);
        c.gridx = 2;
        c.gridy = 1;
        panel.add(b5000, c);
        c.insets = new Insets(40, 0, 0, 0);
        c.gridx = 1;
        c.gridy = 2;
        panel.add(another, c);

        b500.addActionListener(e -> withdraw(500));

        b1000.addActionListener(e -> withdraw(1000));

        b5000.addActionListener(e -> withdraw(5000));

        another.addActionListener(e -> {
            String in = JOptionPane.showInputDialog(getMe(), "Введите сумму", "Снять", JOptionPane.PLAIN_MESSAGE);
            if (Objects.equals(in, "")){
                JOptionPane.showMessageDialog(getMe(), "Вы ничего не ввели!", "Предупреждение", JOptionPane.WARNING_MESSAGE);
            }
            else{
                try{
                    withdraw(Float.parseFloat(in));
                }
                catch (NumberFormatException exc){
                    JOptionPane.showMessageDialog(getMe(), "Некорректный ввод!", "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
                catch (NullPointerException ignored){}
            }
        });

        add(panel);
        setVisible(true);
    }
    private WithdrawWindow getMe(){
        return this;
    }
    private void withdraw(float money){
        try {
            mainWindow.getStartWindow().getAtm().calcWithdraw(money);
            card.withdraw(money);
            mainWindow.setVisible(true);
            mainWindow.getStartWindow().getAtm().incNum();
            JOptionPane.showMessageDialog(getMe(), mainWindow.getStartWindow().getAtm().getCheque(card, money, 1));
            dispose();
        } catch (NotEnoughMoneyException e) {
            if (Objects.equals(e.getMessage(), "ATM not so much money")){
                JOptionPane.showMessageDialog(getMe(), "В банкомате нет такого количества денег!", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(getMe(), "На карте недостаточно средтсв!", "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IncorrectSumException e) {
            JOptionPane.showMessageDialog(getMe(),"Вы не можете внести такую сумму", "Ошибка", JOptionPane.ERROR_MESSAGE);
        }
    }
}
