package com.company.windows;

import com.company.exceptions.NotEnoughMoneyException;
import com.company.realize.CreditCard;
import com.company.realize.DebitCard;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.PlainDocument;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class PhoneTransferWindow extends JFrame {
    public PhoneTransferWindow(String title, DebitCard card, MainWindow mainWindow){
        super(title);
        setBounds(450, 250, 600, 350);
        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                mainWindow.setVisible(true);
                dispose();
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        setLayout(new GridBagLayout());
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        GridBagConstraints mainC = new GridBagConstraints();

        JList<DebitCard> list = new JList<>();
        list.addListSelectionListener(e -> {
            String sum = JOptionPane.showInputDialog(getMe(), "Введите сумму", "Перевод по номеру карты",
                    JOptionPane.PLAIN_MESSAGE);
            try {
                float money = Float.parseFloat(sum);
                card.withdraw(money);
                if (list.getSelectedValue().identify() == 1){
                    CreditCard creditCard = (CreditCard) list.getSelectedValue();
                    if (creditCard.getCalendar() != null) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(new Date());
                        int n = (int) ((calendar.getTimeInMillis()
                                - creditCard.getCalendar().getTimeInMillis()) /
                                (60000 * 1440 * 30));
                        creditCard.update(n);
                    }
                }
                list.getSelectedValue().deposit(money);
                mainWindow.getStartWindow().getAtm().incNum();
                JOptionPane.showMessageDialog(getMe(), mainWindow.getStartWindow().getAtm().getCheque(card, money, 2));
                mainWindow.setVisible(true);
                dispose();
            } catch (NumberFormatException exc) {
                JOptionPane.showMessageDialog(getMe(), "Некорректный ввод!", "Ошибка",
                        JOptionPane.ERROR_MESSAGE);
            } catch (NullPointerException ignored) {
            } catch (NotEnoughMoneyException ex) {
                JOptionPane.showMessageDialog(getMe(), "На карте недостаточно средтсв!",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
        });
        list.setFont(new Font("TimesRoman", Font.BOLD, 15));
        list.setBackground(new java.awt.Color(240,240,240));
        list.setSelectionBackground(new java.awt.Color(240,240,240));

        JLabel label1 = new JLabel("Введите номер телефона");
        label1.setFont(new Font("TimesRoman", Font.BOLD, 20));

        JTextField phoneNumber = new JTextField(10);
        phoneNumber.setFont(new Font("TimesRoman", Font.BOLD, 15));

        JButton submit = new JButton("Подтвердить");
        submit.setFocusable(false);
        submit.setPreferredSize(new Dimension(150,30));
        submit.setFocusable(false);
        submit.setFocusPainted(false);
        submit.setFont(new Font("TimesRoman", Font.BOLD, 15));
        submit.setFocusable(false);

        JLabel label2 = new JLabel("Выберите карту  ");
        label2.setFont(new Font("TimesRoman", Font.BOLD, 20));

        JLabel seven = new JLabel("+7");
        seven.setFont(new Font("TimesRoman", Font.BOLD, 15));

        PlainDocument document = (PlainDocument) phoneNumber.getDocument();
        document.setDocumentFilter(new DocumentFilter() {

            @Override
            public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                String string = fb.getDocument().getText(0, fb.getDocument().getLength()) + text;

                if (string.length() <= 10 && isDigit(string)) {
                    super.replace(fb, offset, length, text, attrs); //To change body of generated methods, choose Tools | Templates.
                }
            }

        });

        submit.addActionListener(e -> {
            String tel = formPhone(phoneNumber.getText());
            ArrayList<DebitCard> array = mainWindow.getStartWindow().getAtm().getCardByTel(tel);
            if (array.size() == 0){
                JOptionPane.showMessageDialog(getMe(), "К этому номеру телефона не прикреплены карты!",
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
            }
            else {
                DebitCard[] cardArr = new DebitCard[array.size()];
                for (int i = 0; i < array.size(); i++)
                    cardArr[i] = array.get(i);
                label2.setForeground(Color.black);
                list.setListData(cardArr);
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(20,0,0,40);
        c.gridx = 0;
        c.gridy = 0;
        panel.add(label1, c);

        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridBagLayout());
        GridBagConstraints c1 = new GridBagConstraints();
        c1.gridx = 0;
        c1.gridy = 0;
        panel1.add(seven);
        c1.insets = new Insets(0,5,0,0);
        c1.gridx = 1;
        panel1.add(phoneNumber, c1);
        c.gridy = 1;
        panel.add(panel1, c);
        c.gridy = 2;
        panel.add(submit, c);

        mainC.gridx = 1;
        mainC.insets = new Insets(0, 40, 0,0);
        c.gridx = 1;
        c.gridy = 0;
        panel.add(label2, c);
        c.gridx = 1;
        c.gridy = 1;
        panel.add(list, c);
        mainPanel.add(panel, mainC);

        add(mainPanel);
        setVisible(true);
    }
    private PhoneTransferWindow getMe(){
        return this;
    }

    private boolean isDigit(String str){
        try{
            Long.parseLong(str);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    private String formPhone(String str){
        StringBuilder bf = new StringBuilder(str);
        bf.insert(3, ')');
        return "7("+ bf;
    }
}
