package com.company.windows;

import com.company.realize.CreditCard;
import com.company.realize.DebitCard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class MainWindow extends JFrame {
    private final StartWindow startWindow;

    public StartWindow getStartWindow() {
        return startWindow;
    }

    public MainWindow(String title, DebitCard card, StartWindow startWindow) {
        super(title);
        this.startWindow = startWindow;
        setBounds(375, 200, 800, 500);
        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                startWindow.setVisible(true);
                dispose();
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        setLayout(new BorderLayout());
        setResizable(false);

        JButton deposit = new JButton();
        JButton transfer = new JButton("Перевести");
        JButton showBalance = new JButton("Показать баланс");
        JButton withdraw = new JButton("Снять");
        JButton showDebt = new JButton("Показать долг");
        JButton exit = new JButton("Завершить");

        deposit.setFocusable(false);
        deposit.setPreferredSize(new Dimension(200,50));
        deposit.setFocusable(false);
        deposit.setFocusPainted(false);
        deposit.setFont(new Font("TimesRoman", Font.BOLD, 15));
        deposit.setFocusable(false);


        transfer.setFocusable(false);
        transfer.setPreferredSize(new Dimension(200,50));
        transfer.setFocusable(false);
        transfer.setFocusPainted(false);
        transfer.setFont(new Font("TimesRoman", Font.BOLD, 15));
        transfer.setFocusable(false);


        showBalance.setFocusable(false);
        showBalance.setPreferredSize(new Dimension(200,50));
        showBalance.setFocusable(false);
        showBalance.setFocusPainted(false);
        showBalance.setFont(new Font("TimesRoman", Font.BOLD, 15));
        showBalance.setFocusable(false);


        withdraw.setFocusable(false);
        withdraw.setPreferredSize(new Dimension(200,50));
        withdraw.setFocusable(false);
        withdraw.setFocusPainted(false);
        withdraw.setFont(new Font("TimesRoman", Font.BOLD, 15));
        withdraw.setFocusable(false);


        showDebt.setFocusable(false);
        showDebt.setPreferredSize(new Dimension(200,50));
        showDebt.setFocusable(false);
        showDebt.setFocusPainted(false);
        showDebt.setFont(new Font("TimesRoman", Font.BOLD, 15));
        showDebt.setFocusable(false);


        exit.setFocusable(false);
        exit.setPreferredSize(new Dimension(200,50));
        exit.setFocusable(false);
        exit.setFocusPainted(false);
        exit.setFont(new Font("TimesRoman", Font.BOLD, 15));
        exit.setFocusable(false);


        if (card.identify() == 0){
            deposit.setText("Внести");
            showDebt.setEnabled(false);
        }
        else{
            deposit.setText("Погасить долг");
            withdraw.setEnabled(false);
        }

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(0,0,0,50);
        c.gridx = 0;
        c.gridy = 0;
        panel.add(deposit, c);
        c.gridx = 1;
        c.gridy = 0;
        panel.add(withdraw, c);
        c.insets = new Insets(0,0,0,0);
        c.gridx = 2;
        c.gridy = 0;
        panel.add(showDebt, c);
        c.insets = new Insets(100,0,0,50);
        c.gridx = 0;
        c.gridy = 1;
        panel.add(transfer, c);
        c.gridx = 1;
        c.gridy = 1;
        panel.add(showBalance, c);
        c.insets = new Insets(100,0,0,0);
        c.gridx = 2;
        c.gridy = 1;
        panel.add(exit, c);

        deposit.addActionListener(e -> {
            setVisible(false);
            new DepositWindow("Внести средства", card, getMe());
        });

        withdraw.addActionListener(e -> {
            setVisible(false);
            new WithdrawWindow("Снятие", card, getMe());
        });

        showDebt.addActionListener(e -> {
            CreditCard creditCard = (CreditCard) card;
            JLabel debt = new JLabel("Ваш долг: " + creditCard.getDebt());
            debt.setFont(new Font("TimesRoman", Font.BOLD, 15));
            JOptionPane.showMessageDialog(getMe(), debt, "Долг", JOptionPane.PLAIN_MESSAGE);
        });

        transfer.addActionListener(e -> new ChoiceWindow("Перевод", card, getMe()));

        showBalance.addActionListener(e -> {
            JLabel balance = new JLabel("Ваш баланс: " + card.getAccount());
            balance.setFont(new Font("TimesRoman", Font.BOLD, 15));
            JOptionPane.showMessageDialog(getMe(), balance, "Баланс", JOptionPane.PLAIN_MESSAGE);
        });

        exit.addActionListener(e -> {
            startWindow.setVisible(true);
            dispose();
        });

        add(panel);
        setVisible(true);
    }
    private MainWindow getMe(){
        return this;
    }
}
