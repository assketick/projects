package com.company.windows;

import com.company.realize.ATM;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException, InvalidFormatException {
        ATM atm = new ATM("123", "123");
        atm.loadData("D://source/data.xlsx");
        atm.show();
        new StartWindow("ATM simulator", atm);
    }
}
