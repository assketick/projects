package com.company.windows;

import com.company.realize.DebitCard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class ChoiceWindow extends JFrame {
    public ChoiceWindow(String title, DebitCard card, MainWindow mainWindow) {
        super(title);
        setBounds(530, 380, 500, 150);
        addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                mainWindow.setVisible(true);
                dispose();
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        setLayout(new BorderLayout());
        setResizable(false);

        JButton bCard = new JButton("По номеру карты");
        bCard.setFocusable(false);
        bCard.setPreferredSize(new Dimension(200,30));
        bCard.setFocusable(false);
        bCard.setFocusPainted(false);
        bCard.setFont(new Font("TimesRoman", Font.BOLD, 15));
        bCard.setFocusable(false);


        JButton bPhone = new JButton("По номеру телефона");
        bPhone.setFocusable(false);
        bPhone.setPreferredSize(new Dimension(200,30));
        bPhone.setFocusable(false);
        bPhone.setFocusPainted(false);
        bPhone.setFont(new Font("TimesRoman", Font.BOLD, 15));
        bPhone.setFocusable(false);


        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        panel.add(bCard, c);
        c.insets = new Insets(0,30,0,0);
        c.gridx = 1;
        c.gridy = 0;
        panel.add(bPhone,c);
        add(panel);

        bCard.addActionListener(e -> {
            new CardTransferWindow("Перевод по номеру карты", card, mainWindow);
            mainWindow.setVisible(false);
            dispose();
        });

        bPhone.addActionListener(e -> {
            new PhoneTransferWindow("Перевод по номеру телефона", card, mainWindow);
            mainWindow.setVisible(false);
            dispose();
        });

        setVisible(true);
    }
}
