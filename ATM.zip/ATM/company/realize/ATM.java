package com.company.realize;

import com.company.exceptions.IncorrectSumException;
import com.company.exceptions.NotEnoughMoneyException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class ATM {
    private final static int COUNT = 100000;
    private final HashMap<String, DebitCard> cardArr;
    private final HashMap<String, ArrayList<String>> telArr;
    private int[] count;
    private int operationNumber;
    private final String atm;
    private final String authorizationCode;

    public ATM(String atm, String authorizationCode) {
        this.atm = atm;
        this.authorizationCode = authorizationCode;
        this.count = new int[]{COUNT, COUNT, COUNT, COUNT, COUNT, COUNT, COUNT};
        this.operationNumber = 0;
        telArr = new HashMap<>();
        cardArr = new HashMap<>();
    }

    //метод заполняющий HashMap из excel файла
    public void loadData(String path) throws IOException {
        FileInputStream fis = new FileInputStream(path);
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        for(Row row: wb.getSheetAt(0)) {
            int index = 0;
            String number = "";
            String bankName = "";
            String paymentSystem = "";
            String owner = "";
            String date = "";
            String telNumber = "";
            int codeCVV = 0;
            int pinCode = 0;
            float account = 0.0F;
            float percent = 0.0F;
            for (Cell cell : row) {
                switch (index) {
                    case 0 -> number = getCellValue(cell);
                    case 1 -> bankName = getCellValue(cell);
                    case 2 -> paymentSystem = getCellValue(cell);
                    case 3 -> owner = getCellValue(cell);
                    case 4 -> date = getCellValue(cell);
                    case 5 -> telNumber = getCellValue(cell);
                    case 6 -> codeCVV = (int)Float.parseFloat(getCellValue(cell));
                    case 7 -> pinCode = (int)Float.parseFloat(getCellValue(cell));
                    case 8 -> account = Float.parseFloat(getCellValue(cell));
                    case 9 -> percent = Float.parseFloat(getCellValue(cell));
                }
                index++;
            }
            if (percent == 0.0F)
                addCard(new DebitCard(number, bankName, paymentSystem, owner, date, telNumber, codeCVV, pinCode, account));
            else
                addCard(new CreditCard(number, bankName, paymentSystem, owner, date, telNumber, codeCVV, pinCode, account, percent));
        }
        fis.close();
    }

    //метод сохраняющий HashMap в excel файл
    /*public void saveData(String path) throws IOException {
        Workbook wb = new XSSFWorkbook();
        Sheet sheet = wb.createSheet();
        int i = 0;
        for(DebitCard value: cardArr.values()) {
            Row row = sheet.createRow(i);
            Cell cell = row.createCell(0);
            cell.setCellValue(value.getNumber());
            cell = row.createCell(1);
            cell.setCellValue(value.getBankName());
            cell = row.createCell(2);
            cell.setCellValue(value.getPaymentSystem());
            cell = row.createCell(3);
            cell.setCellValue(value.getOwner());
            cell = row.createCell(4);
            cell.setCellValue(value.getDate());
            cell = row.createCell(5);
            cell.setCellValue(value.getTelNumber());
            cell = row.createCell(6);
            cell.setCellValue(value.getCodeCVV());
            cell = row.createCell(7);
            cell.setCellValue(value.getPinCode());
            cell = row.createCell(8);
            cell.setCellValue(value.getAccount());
            if (value.identify() == 1) {
                cell = row.createCell(9);
                CreditCard card = (CreditCard) value;
                cell.setCellValue(card.getPercent());
            }
            i++;
        }

        FileOutputStream fos = new FileOutputStream(path);

        wb.write(fos);
        fos.close();
    }*/

    //метод добавления
    public void addCard(DebitCard card) {
        if (cardArr.containsKey(card.getNumber())) delCard(card.getNumber());

        cardArr.put(card.getNumber(), card);

        if(telArr.get(card.getTelNumber()) == null) {
            ArrayList<String> list = new ArrayList<>();
            list.add(card.getNumber());
            telArr.put(card.getTelNumber(), list);
        } else telArr.get(card.getTelNumber()).add(card.getNumber());
    }

    //метод удаления
    public void delCard(String number) {
        DebitCard card = cardArr.get(number);
        if (card != null) {
            ArrayList<String> list = telArr.get(card.getTelNumber());
            if (list.size() > 1) {
                list.remove(number);
            } else {
                telArr.remove(card.getTelNumber());
            }
        }
    }

    //метод выводящий значения коллекции(для проверки)
    public void show() {
        cardArr.forEach((key, value) -> {

            System.out.print(key + " : " + value.getBankName() +
                    " : " + value.getPaymentSystem() + " : "
                    + value.getOwner() + " : " + value.getDate() + " : " + value.getTelNumber() + " : "
                    + value.getCodeCVV() / 100 + value.getCodeCVV() % 100 + " : "
                    + value.getPinCode() / 1000 + value.getPinCode() % 1000 + " : " + value.getAccount());
            if (value.identify() == 0)
                System.out.println();
            else {
                CreditCard card = (CreditCard) value;
                System.out.println(" : " + card.getPercent());
            }

        });
        telArr.forEach((key, value) -> System.out.println(key + " : " + value));
    }

    //метод для получения значения ячейки
    private static String getCellValue(Cell cell) {
        String result = "";
        switch (cell.getCellType()) {
            case STRING:
                result = cell.getStringCellValue();
                break;
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    SimpleDateFormat sdf = new SimpleDateFormat("MM.yyyy");
                    result = sdf.format(cell.getDateCellValue());
                } else {
                    result = Double.toString(cell.getNumericCellValue());
                }
                break;
            case BOOLEAN:
                result = "" + cell.getBooleanCellValue();
                break;
            case FORMULA:
                result = cell.getCellFormula();
        }
        return result;
    }

    //метод для написания чека
    public String getCheque(DebitCard card, float operation, int operationType) {
        String result = "          " + card.getBankName() + "\n";
        result += "        АДРЕС\n";
        result += "    ТЕЛЕФОН СЛУЖБЫ ПОМОЩИ: 911\n\n";
        switch (operationType) {
            case 0 -> result += "      ВЗНОС НАЛИЧНЫХ\n\n";
            case 1 -> result += "      СНЯТИЕ СРЕДСТВ\n\n";
            case 2 -> result += "      ПЕРЕВОД НА КАРТУ\n\n";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss");
        result += "ДАТА: "  + sdf.format(new Date()) + "\n";
        switch (operationType) {
            case 0 -> result += "ВНЕСЕНО НА КАРТУ: " + operation + "\n";
            case 1 -> result += "СНЯТО С КАРТЫ: " + operation + "\n";
            case 2 -> result += "ПЕРЕВЕДЕНО С КАРТЫ: " + operation + "\n";
        }
        result += "КАРТА: ************" + card.getNumber().substring(card.getNumber().length() - 4) + "\n\n";
        result += "НОМЕР ОПЕРАЦИИ: " + operationNumber + "\n";
        result += "БАНКОМАТ: "  + atm + "\n";
        result += "КОД АВТОРИЗАЦИИ: " + authorizationCode;
        return result;
    }

    //методы для расчёта купюр оставшихся в банкомате после снятия денег
    public void calcDeposit(int count50, int count100, int count200, int count500, int count1000, int count2000, int count5000) {
        count[0] += count50;
        count[1] += count100;
        count[2] += count200;
        count[3] += count500;
        count[4] += count1000;
        count[5] += count2000;
        count[6] += count5000;
    }

    public void calcWithdraw(float money) throws IncorrectSumException, NotEnoughMoneyException {
        if (checkSum(money)){
            int[] c = count.clone();
            c[6] -= (int)money / 5000;
            money %= 5000;
            c[5] -= (int)money / 2000;
            money %= 2000;
            c[4] -= (int)money / 1000;
            money %= 1000;
            c[3] -= (int)money / 500;
            money %= 500;
            c[2] -= (int)money / 200;
            money %= 200;
            c[1] -= (int)money / 100;
            money %= 100;
            c[0] -= (int)money / 50;

            for (int i = 6; i > 0; i--) {
                if (c[i] < 0) {
                    if (i == 5 || i == 3) {
                        c[i - 1] -= 2;
                        c[i - 2] -= 1;
                    } else {
                        c[i - 1] -= 2;
                    }
                    c[i] = 0;
                }
            }

            if (c[0]  < 0) throw new NotEnoughMoneyException("ATM not so much money");
            else count = c;

        } else {
            throw new IncorrectSumException("Incorrect sum");
        }
    }

    //метод увеличивающи на 1 номер операции
    public void incNum() { operationNumber++; }

    //метод проверяющий сумму
    private boolean checkSum(float money) {
        return money % 50 == 0;
    }

    // getters и setters
    public DebitCard getCardByNumber(String number) {
        return cardArr.get(number);
    }

    public ArrayList<DebitCard> getCardByTel(String tel) {
        ArrayList<DebitCard> cardList = new ArrayList<>();
        ArrayList<String> list = telArr.get(tel);
        if (list != null) {
            for (String s : list) {
                cardList.add(cardArr.get(s));
            }
        }
        return cardList;
    }
}
