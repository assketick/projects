package com.company.realize;
import com.company.exceptions.NotEnoughMoneyException;

public class DebitCard {

    protected final String number;
    protected final String bankName;
    protected final String paymentSystem;
    protected final String owner;
    protected final String date;
    protected String telNumber;
    protected final int codeCVV;
    protected int pinCode;
    protected float account;                  //money

    public DebitCard(String number, String bankName, String paymentSystem, String owner, String date,
                     String telNumber, int codeCVV, int pinCode, float account) {
        this.number = number;
        this.bankName = bankName;
        this.paymentSystem = paymentSystem;
        this.owner = owner;
        this.date = date;
        this.telNumber = telNumber;
        this.codeCVV = codeCVV;
        this.pinCode = pinCode;
        this.account = account;
    }

    // методы изменение депозита
    public void withdraw(float money) throws NotEnoughMoneyException {
        if (account < money) {
            throw new NotEnoughMoneyException("Not enough money on card's account");
        } else {
            account -= money;
        }
    }

    public void deposit(float money) {
        this.account += money;
    }
    // getters и setters
    public String getNumber() {
        return number;
    }

    public String getBankName() {
        return bankName;
    }

    public String getTelNumber() {
        return telNumber;
    }

    public int getPinCode() {
        return pinCode;
    }

    public String getPaymentSystem() {
        return paymentSystem;
    }

    public String getOwner() {
        return owner;
    }

    public String getDate() {
        return date;
    }

    public int getCodeCVV() {
        return codeCVV;
    }

    public float getAccount() {
        return account;
    }

    //метод определения класса DebitCard - 0, а CreditCard - 1
    public int identify() { return 0; }

    public String toString() {
        return "************" + number.substring(number.length() - 4) + "    " + bankName;
    }
}
