#ifndef METEOSTATION_H
#define METEOSTATION_H
#include <QTextStream>
#include <iostream>
using namespace std;

class Meteostation {
private:
    int temperature;
    int pressure;
    float speed;
    string direction;
public:
    Meteostation();
    Meteostation(const int &temperature, const int &pressure, const float &speed, const string &direction);
    Meteostation(const Meteostation &mt);

    void setTemperature(const int &temperature);
    void setPressure(const int &pressure);
    void setSpeed(const float &speed);
    void setDirection(const string &direction);

    int getTemperature() const { return temperature; }
    int getPressure() const { return pressure; }
    float getSpeed() const { return speed; }
    string getDirection() const { return direction; }

    bool operator != (const Meteostation &m);
};


#endif // METEOSTATION_H
