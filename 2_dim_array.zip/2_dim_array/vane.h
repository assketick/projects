#ifndef VANE_H
#define VANE_H


class Vane{
private:
    float speed;
    char *direction;
public:
    Vane();
    Vane(float speed, char *direction);
    ~Vane();
    Vane(Vane &v);

    void setSpeed(float);
    void setDirection(char &direction);

    float getSpeed() const {return speed;}
    char *getDirection() const {return direction;}

};

#endif // VANE_H
