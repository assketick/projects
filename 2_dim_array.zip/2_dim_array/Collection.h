#ifndef COLLECTION_H
#define COLLECTION_H
#include <iostream>
#include "meteostation.h"
using namespace std;

class Collection {
private:
    int len;
    Meteostation **arr;
public:
    Collection(const int &len);
    Collection(const Collection &c);
    ~Collection();


    Meteostation &getValue(const int &i, const int &j) const;
    int getCount() const;
    int getLen() const {
        return len;
    }
    bool isEq(const Collection &c);
    void delAll();

    //файлы
    void readFile(const string &path);
    void writeFile(const string &path) const;

    //мой метод
    Meteostation Weather(const float &x, const float &y);
};






#endif // COLLECTION_H
