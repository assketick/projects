#include <QCoreApplication>
#include "meteostation.h"
#include "Collection.h"
#include <assert.h>
#include <iostream>
using namespace std;


void showElements(const Collection &c){
    int len = c.getLen();
    for (int i = 0; i < len; i++){
        for (int j = 0; j < len; j++){
            cout << "arr[" << i << "][" << j << "]: " << endl;
            cout << "\t" << c.getValue(i, j).getTemperature() << " degrees" << endl;
            cout << "\t" << c.getValue(i, j).getPressure() << " atmosphere" <<endl;
            cout << "\t" << c.getValue(i, j).getSpeed() << " m/sec" << endl;
            cout << "\t" << c.getValue(i, j).getDirection() << endl;
        }
    }
}
int main()
{

    Meteostation* p = new Meteostation();


    assert(p->getTemperature() == 0); //проверка констр по умолчанию
    assert(p->getPressure() == 0);
    assert(p->getSpeed() == 0.0);
    assert(p->getDirection() == nullptr);


    p->setTemperature(36);  //проверка сеттеров
    p->setPressure(37);
    p->setSpeed(38);
    p->setDirection("West");


    assert(p->getTemperature() == 36);
    assert(p->getPressure() == 37);
    assert(p->getSpeed() == 38);
    assert(!(*p->getDirection()).compare("West"));


    Meteostation* p1 = new Meteostation(36, 37, 38, "West"); //проверка конструктора
    assert(p1->getTemperature() == 36);
    assert(p1->getPressure() == 37);
    assert(p1->getSpeed() == 38);
    assert(!(*p1->getDirection()).compare("West"));


    Meteostation* p2 = new Meteostation(*p1);   //проверка копирования
    assert(p2->getTemperature() == p1->getTemperature());
    assert(p2->getPressure() == p1->getPressure());
    assert(p2->getSpeed() == p1->getSpeed());
    assert(!(*p2->getDirection()).compare(*p1->getDirection()));

    delete p;
    delete p1;
    delete p2;

    cout << "Good\n";


    Collection *c = new Collection(3);              //проверка конструктора инициализации
    c->readFile("D:/qt/labs/mylab1/orig1.txt");    //проверка readFile
    showElements(*c);
    Collection *c1 = new Collection(*c);            //проверка конструктора копирования
    c1->writeFile("D:/qt/labs/mylab1/copy.txt");    //проверка writeFile
    cout << c->isEq(*c1) << endl;;                  //проверка isEq
    c->readFile("D:/qt/labs/mylab1/copy.txt");      //проверка readFile файла, который создал writeFile
    c->writeFile("D:/qt/labs/mylab1/copy_of_copy.txt");         //запись в новый файл данных, которые считал со скопированного файла
    Meteostation son = c->Weather(1.5, 1.5);            //проверка функции расчета погоды
    cout << "Func: " << endl;
    cout << son.getTemperature() << endl;
    cout << son.getPressure() << endl;
    cout << son.getSpeed() << endl;
    cout << son.getDirection() << endl;
    Meteostation son2 = c->getValue(1, 1);      //проверка getValue
    cout << "getValue: " << endl;
    cout << son2.getTemperature() << endl;
    cout << son2.getPressure() << endl;
    cout << son2.getSpeed() << endl;
    cout << son2.getDirection() << endl;
    cout << c->getCount() << " - getCount " <<  endl;          //проверка getCount
    delete c;
    delete c1;
    return(0);
}
