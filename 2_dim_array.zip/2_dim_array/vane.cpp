#include "vane.h"

Vane::Vane(){ // начальные значения
    this->speed = 0.0;
    this->direction = nullptr;
}

Vane::Vane(float speed, char *direction){ // конструктор
    this->speed = speed;
    this->direction = direction;
}

Vane::Vane(Vane &v){ // копирование
    this->speed = v.getSpeed();
    this->direction = v.getDirection();
}

Vane::~Vane(){ // деструктор
    delete &speed;
    delete direction;
}

void Vane::setSpeed(float speed){
    this->speed = speed;
}
void Vane::setDirection(char &direction){
    this->direction = &direction;
}
