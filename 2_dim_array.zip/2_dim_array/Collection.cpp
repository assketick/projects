#include "Collection.h"
#include <iostream>
#include <fstream>
using namespace std;


Collection::Collection(const int &len){    //конструктор инициализации
    this->len = len;
    arr = new Meteostation *[len];
    for (int i = 0; i < len; i++)
        arr[i] = new Meteostation [len];
}

Collection::Collection(const Collection &c){       //copy
    len = c.getLen();
    arr = new Meteostation *[len];
        for (int i = 0; i < len; i++)
            arr[i] = new Meteostation [len];

    for (int i = 0; i < len; i++) {
        for (int j = 0; j < len; j++){
            arr[i][j] = Meteostation(c.getValue(i, j));
        }
    }
}

Collection::~Collection(){          //деструктор
    for (int i = 0; i < len; i++)
        delete []arr[i];
    delete []arr;
}

Meteostation &Collection::getValue(const int &i, const int &j) const {          //получает значение по индексам
    return *(*(arr+i)+j);
}

int Collection::getCount() const{               //получает кол-во элементов массива
    return pow(len, 2);
}

void Collection::delAll(){                      //удаляет все элементы массива
    for (int i = 0; i < len; i++)
        delete []arr[i];
    delete []arr;
    arr = nullptr;
}

bool Collection::isEq(const Collection &c){         //проверка 2х коллекций на равенство
    if (c.getLen() == len){
        for (int i = 0; i < len; i++){
            for (int j = 0; j < len; j++){
                if (arr[i][j] != c.getValue(i, j)) return false;
            }
        }
        return true;
    }
    else return false;
}

void Collection::readFile(const string &path){          //считывает с файла
    if (arr){
        ifstream fin;
        fin.open(path);
        if (fin.is_open()){
            int i = 0;
            int j = 0;
            string str;
            while (!fin.eof() and i < len){
                if (j >= len){
                    i++;
                    j = 0;
                }
                getline(fin, str);
                if (fin.eof()) break;
                if (str == "M"){
                    arr[i][j].setTemperature(stoi(str));
                    getline(fin, str);
                    arr[i][j].setPressure(stoi(str));
                    getline(fin, str);
                    arr[i][j].setSpeed(stof(str));
                    getline(fin, str);
                    arr[i][j].setDirection(str);
                    j++;
                    if (fin.eof()) break;
                }
                else if (str == "F"){
                    arr[i][j].setSpeed(stof(str));
                    getline(fin, str);
                    arr[i][j].setDirection(str);
                    j++;
                    if (fin.eof()) break;
                }
            }
        }
        fin.close();
    }
    else {
        cout << "Array is empty" << endl;
    }
}

void Collection::writeFile(const string &path) const{             //записывает в файл
    if (len > 0 and arr) {
        ofstream fout;
        fout.open(path);
        if (fout.is_open()){
            for (int i=0; i < len; i++){
                for (int j = 0; j < len; j++){
                    fout << arr[i][j].getTemperature() << endl;
                    fout << arr[i][j].getPressure() << endl;
                    fout << arr[i][j].getSpeed() << endl;
                    fout << arr[i][j].getDirection() << endl;
                }
            }
        }
        fout.close();
    }
}

Meteostation Collection::Weather(const float &x, const float &y){           //мой метод
    if (x + y >= 0 and x + y <= 2*len){
        if (int(x) == x or int(y) == y) return Meteostation(arr[int(y)][int(x)]);
        else{
            int i1 = ceil(y), i2 = floor(y);
            int j1 = ceil(x), j2 = floor(x);
            Meteostation q11 = arr[i1][j1], q12 = arr[i1][j2], q21 = arr[i2][j1], q22 = arr[i2][j2];
            Meteostation *result = new Meteostation();
            result->setTemperature(round(q11.getTemperature() + (q21.getTemperature() - q11.getTemperature())\
                * x + (q12.getTemperature() - q11.getTemperature()) * y\
                + (q11.getTemperature()  - q21.getTemperature() - q12.getTemperature()\
                + q22.getTemperature()) * x * y));

            result->setPressure(round(q11.getPressure() + (q21.getPressure() - q11.getPressure()) * x\
                + (q12.getPressure() - q11.getPressure()) * y\
                + (q11.getPressure()  - q21.getPressure() - q12.getPressure() + q22.getPressure()) * x * y));


            result->setSpeed(round((q11.getSpeed() + (q21.getSpeed() - q11.getSpeed()) * x\
                + (q12.getSpeed() - q11.getSpeed()) * y\
                + (q11.getSpeed()  - q21.getSpeed() - q12.getSpeed() + q22.getSpeed()) * x * y) * 100) / 100);

            float max = 0;
            string str;
            if ( q11.getSpeed() > q12.getSpeed()){
                str = q11.getDirection();
                max = q11.getSpeed() ;
            }
            else{
                str = q12.getDirection();
                max = q12.getSpeed() ;
            }
            if (max < q21.getSpeed()){
                str = q21.getDirection();
                max = q21.getSpeed();
            }
            if (max < q22.getSpeed()){
                str = q22.getDirection();
                max = q22.getSpeed();
            }
            result->setDirection(str);
            return *result;
        }
    }
    else return Meteostation();
}
