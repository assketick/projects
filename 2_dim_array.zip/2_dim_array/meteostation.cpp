#include "meteostation.h"
#include <QString>

Meteostation::Meteostation() { // изначальные значения
    this->temperature = 0;
    this->pressure = 0;
    this->speed = 0.0;
    this->direction = "North";
}

Meteostation::Meteostation(const int &temperature, const int &pressure, const float &speed, const string &direction) { //конструктор
    this->temperature = temperature;
    this->pressure = pressure;
    this->speed = speed;
    this->direction = direction;
}

Meteostation::Meteostation(const Meteostation &mt) { // копирование
    this->temperature = mt.getTemperature();
    this->pressure = mt.getPressure();
    this->speed = mt.getSpeed();
    this->direction = mt.getDirection();
}

void Meteostation::setTemperature(const int &temperature) {
    this->temperature = temperature;
}
void Meteostation::setPressure(const int &pressure) {
    this->pressure = pressure;
}
void Meteostation::setSpeed(const float &speed) {
    this->speed = speed;
}
void Meteostation::setDirection(const string &direction) {
    this->direction = direction;
}
bool Meteostation::operator!=(const Meteostation &m){
    bool flag1 = this->getTemperature() == m.getTemperature();
    bool flag2 = this->getPressure() == m.getPressure();
    bool flag3 = this->getSpeed() == m.getSpeed();
    bool flag4 = this->getDirection() == m.getDirection();
    return !(flag1 && flag2 && flag3 && flag4);
}
